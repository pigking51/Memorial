package dw.movieDic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class movieDicApplication {

	public static void main(String[] args) {
		SpringApplication.run(movieDicApplication.class, args);
	}

}
