using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LikeScore : MonoBehaviour
{
    public static int likeScore = 0; // ��õ ��

}

