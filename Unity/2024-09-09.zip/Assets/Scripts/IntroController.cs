using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IntroController : MonoBehaviour
{
    public GameObject introPanel;
    public GameObject introBackground;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    void DestroyIntro()
    {
        Destroy(introPanel);
    }

    void DestroyBackground()
    {
        Destroy(introBackground);
    }

    // Update is called once per frame
    void Update()
    {
        Invoke("DestroyIntro", 5.4f);
        Invoke("DestroyBackground", 6.4f);
    }
}
