package dw.memorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class memorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
