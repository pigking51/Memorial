package dw.memorial.Repository;

import dw.memorial.Model.FranchiseInquery;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FranchiseInqueryRepository extends JpaRepository<FranchiseInquery, Long> {
}
