package dw.memorial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class memorialApplication {

	public static void main(String[] args) {
		SpringApplication.run(memorialApplication.class, args);
	}

}
